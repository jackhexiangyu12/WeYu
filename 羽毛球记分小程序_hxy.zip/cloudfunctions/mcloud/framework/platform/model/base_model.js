/**
 * Notes: 实体基类 
 * Date: 2021-03-15 19:20:00 
 * Ver : CCMiniCloud Framework 2.0.6 ALL RIGHTS RESERVED BY he_xiang_yu (wechat)
 */


const MultiModel = require('../../../framework/database/multi_model.js');

class BaseModel extends MultiModel {

}

module.exports = BaseModel;