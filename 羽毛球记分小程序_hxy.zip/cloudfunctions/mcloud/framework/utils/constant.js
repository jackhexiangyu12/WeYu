 /**
 * Notes: 通用常量定义
 * Ver : CCMiniCloud Framework 2.32.1 ALL RIGHTS RESERVED BY he_xiang_yu (wechat)
 * Date: 2020-09-05 04:00:00 
 */
module.exports = {
 
}