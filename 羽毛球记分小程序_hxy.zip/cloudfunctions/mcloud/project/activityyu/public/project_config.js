module.exports = {   
	// ## 缓存相关  
	CACHE_CALENDAR_TIME: 60 * 30, //日历缓存      
 
}