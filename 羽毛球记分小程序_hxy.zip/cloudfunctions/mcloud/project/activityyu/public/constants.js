module.exports = {    
	// 首页推荐
	SETUP_HOME_VOUCH_KEY : 'SETUP_HOME_VOUCH_KEY',
}