/**
 * Notes: 用户中心模块控制器
 * Date: 2021-03-15 19:20:00 
 * Ver : CCMiniCloud Framework 2.0.1 ALL RIGHTS RESERVED BY he_xiang_yu (wechat)
 */

const BaseProjectController = require('./base_project_controller.js');

class MyController extends BaseProjectController { 

}

module.exports = MyController;