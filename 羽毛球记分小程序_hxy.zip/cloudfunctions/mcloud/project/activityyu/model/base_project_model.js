/**
 * Notes: 实体ORM基类 
 * Date: 2022-03-15 19:20:00 
 * Ver : CCMiniCloud Framework 2.0.1 ALL RIGHTS RESERVED BY he_xiang_yu (wechat)
 */


const BaseModel = require('../../../framework/platform/model/base_model.js');

class BaseProjectModel extends BaseModel {


}

module.exports = BaseProjectModel;