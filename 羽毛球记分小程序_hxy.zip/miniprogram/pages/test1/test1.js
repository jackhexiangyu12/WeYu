const myFavBh = require('../../comm/behavior/my_fav_bh.js');
const myFootBh = require('../../comm/behavior/my_foot_bh.js');
const newsIndexBh = require('../../comm/behavior/news_index_bh.js');
const searchBh = require('../../comm/behavior/search_bh.js');
const favBiz = require('../../comm/biz/fav_biz.js');
const fileHelper = require('../../helper/file_helper.js');
const qr = require('../../lib/tools/qrcode_lib.js');
const base64 = require('../../lib/tools/base64_lib.js')
const miniHelper = require('../../helper/mini_helper.js')
const formHelper = require('../../helper/form_helper.js') 
Page({

	/**
	 * 页面的初始数据
	 */
	data: {

	},

	/**
	 * 生命周期函数--监听页面加载
	 */
	onLoad(options) {

	},

	/**
	 * 生命周期函数--监听页面初次渲染完成
	 */
	onReady() {

	},

	/**
	 * 生命周期函数--监听页面显示
	 */
	onShow() {

	},

	/**
	 * 生命周期函数--监听页面隐藏
	 */
	onHide() {

	},

	/**
	 * 生命周期函数--监听页面卸载
	 */
	onUnload() {

	},

	/**
	 * 页面相关事件处理函数--监听用户下拉动作
	 */
	onPullDownRefresh() {

	},

	/**
	 * 页面上拉触底事件的处理函数
	 */
	onReachBottom() {

	},

	/**
	 * 用户点击右上角分享
	 */
	onShareAppMessage() {

	}
})